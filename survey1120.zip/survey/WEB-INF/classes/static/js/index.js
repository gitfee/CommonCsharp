function getUserInfo() {
    $.ajax({
        type: "GET",
        url: "http://ina001p021:19975/sofia/user/checkUserInfo",
        xhrFields: {
            withCredentials: true
        },
        crossDomain: true,
        dataType: 'json',
        success: function (result) {
            if (result.code == 200) {
                login(result.data.username);
            }
        },
        error: function (e) {
            errorAlert('The connection attempt failed')
        }
    });
}

function login(username){
    $.ajax({
        url: ROOT_API + 'user/loginWithUsername',
        type: 'post',
        data: {
            username: username
        },
        success: function (res) {
            console.log(res)
            if (res.status) {
                $('#username').html(res.shiroUser.firstName + ' ' + res.shiroUser.lastName);
                var s = false;
                var html = '';
                var uri = '';
                for (var i in res.shiroUser.resourcesList) {
                    if (!res.shiroUser.resourcesList[i].parentKey) {
                        var m1 = res.shiroUser.resourcesList[i];
                        var css1 = '';
                        if (!s && m1.uri) {
                            css1 = 'active';
                            s = true;
                            uri = m1.uri;
                        }
                        html += '<h3 class="' + css1 + '"><a href="' + m1.uri + '" class="rightBox">' + m1.name + '</a></h3>';
                        html += '<ul>';
                        for (var j in res.shiroUser.resourcesList) {
                            if (res.shiroUser.resourcesList[i].keycode == res.shiroUser.resourcesList[j].parentKey) {
                                var m2 = res.shiroUser.resourcesList[j];
                                var css2 = '';
                                if (!s && m2.uri) {
                                    css2 = 'active';
                                    s = true;
                                    uri = m2.uri;
                                }
                                html += '<li class="' + css2 + '"><a href="' + m2.uri + '" class="rightBox">' + m2.name + '</a></li>';
                            }
                        }
                        html += '</ul>';
                    }
                }
                $('#nevBox').html($('#nevBox').html() + html);
                $('#iframeSon').attr('src', uri);
                $('.rightBox').click(function () {
                    if ($(this).attr('href')) {
                        $('#iframeSon').attr('src', $(this).attr('href'));
                        $('.sidenav').find('li,h3').removeClass('active');
                        $(this).parent().addClass('active');
                    }
                    return false;
                });
            } else {
                errorAlert(res.msg)
            }
        },
        error: function () {
            errorAlert('The connection attempt failed')
        },
        dataType: 'json'
    });
}

// getUserInfo();
login('thomas');

function toChangePage(page){
    $('.sidenav li').removeClass('active');
    if(page == 'perUser'){
        $('.sidenav li').each(function (i, v) {
            var oA = $(this).find('a').html()
            if(oA == 'Per User'){
                var index = i;
                $('.sidenav li').eq(index).addClass('active');
            }
        })
    }else if(page == 'perQuestion'){
        $('.sidenav li').each(function (i, v) {
            var oA = $(this).find('a').html()
            if(oA == 'Per Question'){
                var index = i;
                $('.sidenav li').eq(index).addClass('active');
            }
        })
    }
}

$('#type').change(function () {
    var type = $('#type option:selected').text()
    initAnswer();
    if (type == 'LEVEL') {
        $('.operation').hide();
    } else if (type == 'BUCKET') {
        $('.operation').show();
    }
});
$('.operation .addanswer').click(function () {
    var html = '<div class="answer">' +
        '<span>option</span><input class="answers" type="text" placeholder="Please input option">' +
        '</div>';
    $('.answer-wrapper').append(html);
});
$('.operation .delanswer').click(function () {
    var len = $('.answer-wrapper .answer').length;
    if (len <= 1) {
        return false;
    }
    $('.answer-wrapper .answer').eq(len - 1).remove();
});
var parent_id = '';
var survey_id = '';
var question_id = '';

function getSurveyDetails(id) {
    $('.surveyDetails').fadeIn();
    $.ajax({
        url: ROOT_API + 'survey/getSurvey',
        type: 'post',
        data: {
            'survey_id': id
        },
        success: function (res) {
            $('#surveyDetails').val(res.questionNode.surveyName);
            $('#surveyDetailsDesc').val(res.questionNode.surveyDesc);
            $('#surveyDetailsShorizon').val(res.questionNode.surveyHorizon);
            $('#surveyDetailsTime1').val(changeDate(res.questionNode.beginSurveyDate));
            $('#surveyDetailsTime2').val(changeDate(res.questionNode.endSurveyDate));
        },
        error: function () {
            window.parent.errorAlert('The connection attempt failed')
        },
        dataType: 'json'
    })
}

function getQuestionDetails(id) {
    $('.questionDetails').fadeIn();
    $.ajax({
        url: ROOT_API + 'question/getQuestion',
        type: 'post',
        data: {
            'survey_question_id': id
        },
        success: function (res) {
            $("#questionDetailsSurvey").val(res.questionNode.surveyId);
            $('#questionDetailsQuestion').val(res.questionNode.surveyQuestion);
            $('#questionDetailsDesc').val(res.questionNode.surveyQuestionDesc);
            $("#questionDetailsType").val(res.questionNode.surveyQuestionType);
            var html = ''
            for (var i in res.questionNode.answersArray) {
                html += '<div class="answer">' +
                    '<span>option</span><input value="' + res.questionNode.answersArray[i].surveyAnswer + '" class="answers" type="text" disabled>' +
                    '</div>'
            }
            $('.answer-box').html(html);
        },
        error: function () {
            window.parent.errorAlert('The connection attempt failed')
        },
        dataType: 'json'
    })
}

function getQuestionType() {
    $.ajax({
        url: ROOT_API + 'constants/getList',
        type: 'post',
        data: {
            'mark': 'QUESTION_TYPE'
        },
        success: function (res) {
            var html = '<option value="">Please choose type</option>';
            for (var i in res) {
                html += '<option value="' + res[i].valueStirng + '">' + res[i].textString + '</option>'
            }
            $('#type').html(html);
            if ($('#questionDetailsType').length > 0) {
                $('#questionDetailsType').html(html);
            }
        },
        error: function () {
            window.parent.errorAlert('The connection attempt failed')
        },
        dataType: 'json'
    })
}

function popit(obj, id , parentId) {
    parent_id = parentId
    if (obj == 'survey') {
        $('.survey').fadeIn();
        if (id) {
            survey_id = id;
            $('#surveyEditBtn').show();
            $('#surveyAddBtn').hide();
            $.ajax({
                url: ROOT_API + 'survey/getSurvey',
                type: 'post',
                data: {
                    'survey_id': id
                },
                success: function (res) {
                    $('#survey').val(res.questionNode.surveyName);
                    $('#sdesc').val(res.questionNode.surveyDesc);
                    $('#shorizon').val(res.questionNode.surveyHorizon);
                    $('#time1').val(changeDate(res.questionNode.beginSurveyDate));
                    $('#time2').val(changeDate(res.questionNode.endSurveyDate));
                },
                error: function () {
                    window.parent.errorAlert('The connection attempt failed')
                },
                dataType: 'json'
            })
        } else {
            initMaskForm();
            $('#surveyEditBtn').hide();
            $('#surveyAddBtn').show();
        }
    } else if (obj == 'question') {
        getQuestionType();
        getSurveyList(id);
    }
}

/* Question Mask*/
function getSurveyList(id, type) {
    $('.loading', window.parent.document).fadeIn();
    $.ajax({
        url: ROOT_API + 'survey/getSurveyList',
        type: 'post',
        data: {},
        success: function (res) {
            $('.loading', window.parent.document).fadeOut();
            var html = '<option value="">Please choose survey</option>';
            for (var i in res) {
                html += '<option value="' + res[i].surveyId + '">' + res[i].surveyName + '</option>'
            }
            if(type == 'question'){
                $('#questionDetailsSurvey').html(html);
                getQuestionDetails(id);
            }else{
                $('#qsurvey').html(html);
                getQuestionInfo(id);
                $('#qsurvey').val(parent_id)
            }
        },
        error: function () {
            $('.loading', window.parent.document).fadeOut();
            window.parent.errorAlert('The connection attempt failed')
        },
        dataType: 'json'
    })
}

/*获取question详情*/
function getQuestionInfo(id) {
    $('.question').fadeIn();
    if (id) {
        question_id = id;
        $('#questionEditBtn').show();
        $('#questionAddBtn').hide();
        $.ajax({
            url: ROOT_API + 'question/getQuestion',
            type: 'post',
            data: {
                'survey_question_id': id
            },
            success: function (res) {
                $("#qsurvey").val(res.questionNode.surveyId);
                $('#question').val(res.questionNode.surveyQuestion)
                $('#qdesc').val(res.questionNode.surveyQuestionDesc)
                $("#type").val(res.questionNode.surveyQuestionType);
                if(res.questionNode.surveyQuestionType == 1){
                    $('.operation').hide();
                }else if(res.questionNode.surveyQuestionType == 2){
                    $('.operation').show();
                }
                var html = ''
                for (var i in res.questionNode.answersArray) {
                    html += '<div class="answer">' +
                        '<span>option</span><input value="' + res.questionNode.answersArray[i].surveyAnswer + '" class="answers" type="text">' +
                        '</div>'
                }

                $('.answer-wrapper').html(html);
            },
            error: function () {
                window.parent.errorAlert('The connection attempt failed')
            },
            dataType: 'json'
        })
    } else {
        initMaskForm();
        $('#questionEditBtn').hide();
        $('#questionAddBtn').show();
    }
}

function delMaskShow(type, id, surveyId) {
    var dataType = type
    var dataId = id
    parent_id = surveyId
    $('.delMask').fadeIn();
    $('.delBtn').click(function () {
        if (dataType == 'survey') {
            $.ajax({
                url: ROOT_API + 'survey/delSurvey',
                type: 'post',
                data: {
                    'survey_id': dataId
                },
                success: function (res) {
                    if(res.status){
                        $('.delMask').fadeOut();
                        document.getElementById("iframeSon").contentWindow.getSurveyList();
                    }else{
                        window.parent.errorAlert(res.msg);
                    }
                    dataType = '';
                    dataId = ''
                },
                error: function () {
                    window.parent.errorAlert('The connection attempt failed')
                },
                dataType: 'json'
            })
        } else if (dataType == 'question') {
            $.ajax({
                url: ROOT_API + 'question/delQuestion',
                type: 'post',
                data: {
                    'survey_question_id': dataId
                },
                success: function (res) {
                    if(res.status){
                        $('.delMask').fadeOut();
                        document.getElementById("iframeSon").contentWindow.getQuestionList(parent_id);
                    }else {
                        window.parent.errorAlert(res.msg);
                    }
                    dataType = '';
                    dataId = ''
                },
                error: function () {
                    window.parent.errorAlert('The connection attempt failed')
                },
                dataType: 'json'
            })
        }
    })
}

$('.close,.qx').click(function () {
    $('.mask').fadeOut();
    initAnswer();
});

$('#surveyAddBtn').click(function () {
    var surveyName = $('#survey').val()
    var surveyDesc = $('#sdesc').val()
    var surveyHorizon = $('#shorizon').val()
    var beginSurveyDate = $('#time1').val()
    var endSurveyDate = $('#time2').val()
    if(surveyName == '' || surveyDesc == '' || surveyHorizon == '' || beginSurveyDate == '' || endSurveyDate == ''){
        window.parent.errorAlert('Please fill up all data fields!')
        return false;
    }
    $.ajax({
        url: ROOT_API + 'survey/addSurvey',
        type: 'post',
        data: {
            'surveyName': surveyName,
            'surveyDesc': surveyDesc,
            'surveyHorizon': surveyHorizon,
            'beginSurveyDate': beginSurveyDate,
            'endSurveyDate': endSurveyDate
        },
        success: function (res) {
            $('.mask').fadeOut();
            initMaskForm();
            document.getElementById("iframeSon").contentWindow.getSurveyList();
            window.parent.errorAlert('Submit Successful')
        },
        error: function () {
            window.parent.errorAlert('The connection attempt failed')
        },
        dataType: 'json'
    })
});
$('#surveyEditBtn').click(function () {
    var surveyName = $('#survey').val()
    var surveyDesc = $('#sdesc').val()
    var surveyHorizon = $('#shorizon').val()
    var beginSurveyDate = $('#time1').val()
    var endSurveyDate = $('#time2').val()
    if(surveyName == '' || surveyDesc == '' || surveyHorizon == '' || beginSurveyDate == '' || endSurveyDate == ''){
        window.parent.errorAlert('Please fill up all data fields!')
        return false;
    }
    $.ajax({
        url: ROOT_API + 'survey/editSurvey',
        type: 'post',
        data: {
            'survey_id': survey_id,
            'surveyName': surveyName,
            'surveyDesc': surveyDesc,
            'surveyHorizon': surveyHorizon,
            'beginSurveyDate': beginSurveyDate,
            'endSurveyDate': endSurveyDate
        },
        success: function (res) {
            $('.mask').fadeOut();
            initMaskForm();
            document.getElementById("iframeSon").contentWindow.getSurveyList();
            window.parent.errorAlert('Submit Successful')
        },
        error: function () {
            window.parent.errorAlert('The connection attempt failed')
        },
        dataType: 'json'
    })
});

$('#questionAddBtn').click(function () {
    var survey_id = $('#qsurvey option:selected').val()
    var surveyQuestion = $('#question').val()
    var surveyQuestionDesc = $('#qdesc').val()
    var surveyQuestionType = $('#type option:selected').val();
    var answersArr = [];
    $('.answer-wrapper .answer').each(function () {
        answersArr.push($(this).find('.answers').val())
    });
    if(survey_id == '' || surveyQuestion == '' || surveyQuestionDesc == '' || surveyQuestionType == '' || answersArr[0] == ''){
        window.parent.errorAlert('Please fill up all data fields!')
        return false;
    }
    $.ajax({
        url: ROOT_API + 'question/addQuestion',
        type: 'post',
        data: {
            'survey_id': survey_id,
            'surveyQuestion': surveyQuestion,
            'surveyQuestionDesc': surveyQuestionDesc,
            'surveyQuestionType': surveyQuestionType,
            'surveyAnswers': answersArr
        },
        success: function (res) {
            $('.mask').fadeOut();
            initMaskForm();
            initAnswer();
            document.getElementById("iframeSon").contentWindow.getQuestionList(parent_id);
            window.parent.errorAlert('Submit Successful')
        },
        error: function () {
            window.parent.errorAlert('The connection attempt failed')
        },
        dataType: 'json'
    })
});
$('#questionEditBtn').click(function () {
    var survey_id = $('#qsurvey option:selected').val()
    var surveyQuestion = $('#question').val()
    var surveyQuestionDesc = $('#qdesc').val()
    var surveyQuestionType = $('#type option:selected').val();
    var answersArr = [];
    $('.answer-wrapper .answer').each(function () {
        answersArr.push($(this).find('.answers').val())
    });
    if(survey_id == '' || surveyQuestion == '' || surveyQuestionDesc == '' || surveyQuestionType == '' || answersArr[0] == ''){
        window.parent.errorAlert('Please fill up all data fields!')
        return false;
    }
    $.ajax({
        url: ROOT_API + 'question/editQuestion',
        type: 'post',
        data: {
            'survey_question_id': question_id,
            'survey_id': survey_id,
            'surveyQuestion': surveyQuestion,
            'surveyQuestionDesc': surveyQuestionDesc,
            'surveyQuestionType': surveyQuestionType,
            'surveyAnswers': answersArr
        },
        success: function (res) {
            $('.mask').fadeOut();
            initMaskForm();
            initAnswer();
            document.getElementById("iframeSon").contentWindow.getQuestionList(parent_id);
            window.parent.errorAlert('Submit Successful')
        },
        error: function () {
            window.parent.errorAlert('The connection attempt failed')
        },
        dataType: 'json'
    })
});

function initMaskForm() {
    $('.mask input').val("");
    $('.mask textarea').val("");
    $('.mask select option').attr("selected", false)
}

function initAnswer() {
    var html = '<div class="answer">' +
        '<span>option</span><input class="answers" type="text" placeholder="Please input option">' +
        '</div>'
    $('.answer-wrapper').html(html)
}