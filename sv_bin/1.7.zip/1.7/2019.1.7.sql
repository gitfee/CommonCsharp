create table PM_OWN.SURVEY_INVENTORY_GROUP
(
  survey_id NVARCHAR2(32),
  group_id  NVARCHAR2(32)
)

create table PM_OWN.SURVEY_QUESTIONS_GROUP
(
  survey_question_id NVARCHAR2(32),
  group_id           NVARCHAR2(32)
)

create table PM_OWN.SURVEY_SYS_GROUP
(
  keycode             NVARCHAR2(32) not null,
  group_name          NVARCHAR2(200),
  group_desc          NVARCHAR2(500),
  group_creator       NVARCHAR2(32),
  group_creation_date TIMESTAMP(6)
)

create table PM_OWN.SURVEY_SYS_USER_GROUP
(
  user_key  NVARCHAR2(32),
  group_key NVARCHAR2(32)
)

alter table PM_OWN.SURVEY_INVENTORY add (EVERYONE NUMBER(11));
alter table PM_OWN.SURVEY_QUESTIONS add (EVERYONE NUMBER(11));
alter table PM_OWN.SURVEY_QUESTIONS add (SURVEY_QUESTION_LIMIT NUMBER(11));

insert into PM_OWN.SURVEY_SYS_CONSTANTS (keycode, type_key, type_name, type_mark, relation_key, parent_key, value_stirng, text_string, sort)
values ('a9ebb1c63a084b87b1b040281e040e9c', null, 'questionAnswerRestriction', 'QUESTION_ANSWER_RESTRICTION', null, null, null, null, 103);
insert into PM_OWN.SURVEY_SYS_CONSTANTS (keycode, type_key, type_name, type_mark, relation_key, parent_key, value_stirng, text_string, sort)
values ('979fc72bafd342239bb2c4a6481e90d6', 'a9ebb1c63a084b87b1b040281e040e9c', 'questionAnswerRestriction', 'QUESTION_ANSWER_RESTRICTION', null, null, '1', 'ONCE', 1);
insert into PM_OWN.SURVEY_SYS_CONSTANTS (keycode, type_key, type_name, type_mark, relation_key, parent_key, value_stirng, text_string, sort)
values ('749591eac6ad4f90b61adf1d6d1df448', 'a9ebb1c63a084b87b1b040281e040e9c', 'questionAnswerRestriction', 'QUESTION_ANSWER_RESTRICTION', null, null, '2', 'MANY_TIMES', 2);
insert into PM_OWN.SURVEY_SYS_CONSTANTS (keycode, type_key, type_name, type_mark, relation_key, parent_key, value_stirng, text_string, sort)
values ('59b139eae51741738f7f5492378080a5', null, 'accessType', 'Access_Type', null, null, null, null, 104);
insert into PM_OWN.SURVEY_SYS_CONSTANTS (keycode, type_key, type_name, type_mark, relation_key, parent_key, value_stirng, text_string, sort)
values ('d97d0962a4df439e9e91cba57f02c996', '59b139eae51741738f7f5492378080a5', 'accessType', 'Access_Type', null, null, '1', 'ALLOW', 1);
insert into PM_OWN.SURVEY_SYS_CONSTANTS (keycode, type_key, type_name, type_mark, relation_key, parent_key, value_stirng, text_string, sort)
values ('5b5d9cbc802d4cc5ae22e2d90bd4c25a', '59b139eae51741738f7f5492378080a5', 'accessType', 'Access_Type', null, null, '2', 'DENIAL', 2);