
var ROOT_API = "http://127.0.0.1:8080/survey/";

var GetUserInfoRUI = "http://192.168.1.25:9001/user.ashx";

function changeDate(ttDate){
    return ttDate.replace(/(\d{4}).(\d{1,2}).(\d{1,2}).+/mg, '$1-$2-$3');
}

function toPerUser(username) {
    localStorage.setItem('perUserName', username);
    window.location.href =  'perUser.html';
    window.parent.toChangePage('perUser');
}

function toPerQuestion(surveyId,QuestionId) {
    localStorage.setItem('surveyId', surveyId);
    localStorage.setItem('QuestionId', QuestionId);
    window.location.href =  'perQuestion.html';
    window.parent.toChangePage('perQuestion');
}

function errorAlert(msg) {
    $('.error').fadeIn();
    $('.errorMsg').html(msg);
}

$('.errorBtn,.errorClose').click(function () {
    $('.error').fadeOut();
})

laydate.render({
    elem: '#shorizon',
    lang: 'en'
});
laydate.render({
    elem: '#time1',
    lang: 'en'
});
laydate.render({
    elem: '#time2',
    lang: 'en'
});

$(function () {
    $('.sidenav li a').click(function () {
        document.title = $(this).html()
    })
});