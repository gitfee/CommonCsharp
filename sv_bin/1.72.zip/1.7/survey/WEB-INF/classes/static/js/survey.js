
var ROOT_API = "http://127.0.0.1:8080/survey/";

var GetUserInfoRUI = "http://ina001p021:19975/sofia/user/checkUserInfo";


function getUserInfo() {
    $.ajax({
        type: "GET",
        url: GetUserInfoRUI,
        xhrFields: {
            withCredentials: true
        },
        crossDomain: true,
        dataType: 'json',
        success: function (result) {
            if (result.code == 200) {
                login(result.data.username);
            }
        },
        error: function (e) {
            errorAlert('The connection attempt failed')
        }
    });
}

function login(username){
    $.ajax({
        url: ROOT_API + 'user/loginWithUsername',
        type: 'post',
        data: {
            username: username
        },
        success: function (res) {
            if (res.status) {
                $('#username').html(res.shiroUser.displayName);
                var s = false;
                var html = '';
                var uri = '';
                for (var i in res.shiroUser.resourcesList) {
                    if (!res.shiroUser.resourcesList[i].parentKey) {
                        var m1 = res.shiroUser.resourcesList[i];
                        var css1 = '';
                        if (!s && m1.uri) {
                            css1 = 'active';
                            s = true;
                            uri = m1.uri;
                        }
                        html += '<h3 class="' + css1 + '"><a href="' + m1.uri + '" class="rightBox">' + m1.name + '</a></h3>';
                        html += '<ul>';
                        for (var j in res.shiroUser.resourcesList) {
                            if (res.shiroUser.resourcesList[i].keycode == res.shiroUser.resourcesList[j].parentKey) {
                                var m2 = res.shiroUser.resourcesList[j];
                                var css2 = '';
                                if (!s && m2.uri) {
                                    css2 = 'active';
                                    s = true;
                                    uri = m2.uri;
                                }
                                html += '<li class="' + css2 + '"><a href="' + m2.uri + '" class="rightBox">' + m2.name + '</a></li>';
                            }
                        }
                        html += '</ul>';
                    }
                }
                $('#nevBox').html($('#nevBox').html() + html);
                $('#iframeSon').attr('src', uri);
                $('.rightBox').click(function () {
                    if ($(this).attr('href')) {
                        $('#iframeSon').attr('src', $(this).attr('href'));
                            $('.sidenav').find('li,h3').removeClass('active');
                        $(this).parent().addClass('active');
                    }
                    return false;
                });
            } else {
                errorAlert(res.msg)
            }
        },
        error: function () {
            errorAlert('The connection attempt failed')
        },
        dataType: 'json'
    });
}

// getUserInfo();
login('thomas');

function toChangePage(page){
    $('.sidenav li').removeClass('active');
    if(page == 'perUser'){
        $('.sidenav li').each(function (i, v) {
            var oA = $(this).find('a').html()
            if(oA == 'Per User'){
                var index = i;
                $('.sidenav li').eq(index).addClass('active');
            }
        })
    }else if(page == 'perQuestion'){
        $('.sidenav li').each(function (i, v) {
            var oA = $(this).find('a').html()
            if(oA == 'Per Question'){
                var index = i;
                $('.sidenav li').eq(index).addClass('active');
            }
        })
    }
}


function changeDate(ttDate){
    return ttDate.replace(/(\d{4}).(\d{1,2}).(\d{1,2}).+/mg, '$1-$2-$3');
}

function toPerUser(username) {
    localStorage.setItem('perUserName', username);
    window.location.href =  'perUser.html';
    window.parent.toChangePage('perUser');
}

function toPerQuestion(surveyId,QuestionId) {
    localStorage.setItem('surveyId', surveyId);
    localStorage.setItem('QuestionId', QuestionId);
    window.location.href =  'perQuestion.html';
    window.parent.toChangePage('perQuestion');
}

var layer = {
    init: function (msg) {
        var html = '<div class="layer-wrapper tip-wrapper">' +
            '        <div class="layer tip sm">' +
            '            <div class="layer-title">' +
            '                <span class="closebtn" onclick="layer.close()"></span>' +
            '            </div>' +
            '            <div class="layer-body">' +
            '                <p class="msg">'+ msg +'</p>'+
            '            </div>' +
            '            <div class="layer-footer">' +
            '                <button onclick="layer.close()" class="btn btn-primary">Ok</button>' +
            '            </div>' +
            '        </div>' +
            '    </div>';
        $('.container-fluid').append(html);
    },
    close: function () {
        $('.tip-wrapper').remove();
    }
}

var loading = {
    init : function () {
        var html = '<img class="load" src="../img/load.gif" alt="">'
        $('.container-fluid').append(html);
    },
    close: function () {
        $('.load').remove();
    }
};

$('.closebtn').click(function () {
    $('.layer-wrapper').fadeOut();
});

var form = {
    init: function () {
        $('.layer-wrapper .input').val("");
        $('.layer-wrapper textarea').val("");
        $('.layer-wrapper select option').attr("selected", false)
    }
};
