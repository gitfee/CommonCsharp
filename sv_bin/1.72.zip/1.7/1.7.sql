insert into SURVEY_SYS_RESOURCES (keycode, parent_key, name, uri, type, sort)
values ('02d3e173971b4fc8b7af81d412e7dfa3', null, 'Permission', null, 1, 4);
insert into SURVEY_SYS_RESOURCES (keycode, parent_key, name, uri, type, sort)
values ('0338f1cc15114d8c825ca8dba68573b6', '02d3e173971b4fc8b7af81d412e7dfa3', 'Users', 'page/users.html', 1, 1);
insert into SURVEY_SYS_RESOURCES (keycode, parent_key, name, uri, type, sort)
values ('03462d673c7e4b329434fb45191e1284', '02d3e173971b4fc8b7af81d412e7dfa3', 'Group', 'page/group.html', 1, 2);
insert into SURVEY_SYS_RESOURCES (keycode, parent_key, name, uri, type, sort)
values ('046b253e546b4b7eb15d06d301760cda', '02d3e173971b4fc8b7af81d412e7dfa3', 'Per Surveys', 'page/perSurveys.html', 1, 3);
insert into SURVEY_SYS_RESOURCES (keycode, parent_key, name, uri, type, sort)
values ('0987047b272d46f39101eef902fc4c7c', '02d3e173971b4fc8b7af81d412e7dfa3', 'Per Questions', 'page/perQuestions.html', 1, 4);


insert into SURVEY_SYS_ROLE_RESOURCES (role_key, resources_key)
values ('2f1b6447ef3745fd8441b5a5267c2073', '02d3e173971b4fc8b7af81d412e7dfa3');
insert into SURVEY_SYS_ROLE_RESOURCES (role_key, resources_key)
values ('2f1b6447ef3745fd8441b5a5267c2073', '0338f1cc15114d8c825ca8dba68573b6');
insert into SURVEY_SYS_ROLE_RESOURCES (role_key, resources_key)
values ('2f1b6447ef3745fd8441b5a5267c2073', '03462d673c7e4b329434fb45191e1284');
insert into SURVEY_SYS_ROLE_RESOURCES (role_key, resources_key)
values ('2f1b6447ef3745fd8441b5a5267c2073', '046b253e546b4b7eb15d06d301760cda');
insert into SURVEY_SYS_ROLE_RESOURCES (role_key, resources_key)
values ('2f1b6447ef3745fd8441b5a5267c2073', '0987047b272d46f39101eef902fc4c7c');